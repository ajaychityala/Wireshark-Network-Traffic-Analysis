# 🌐 Wireshark Network Traffic Analysis – Task 5

Welcome to this repository! This project captures the essentials of analyzing network traffic using **Wireshark**, a powerful and widely used network protocol analyzer.

## 📚 Overview

This repository was created as part of a practical task titled **"Capture and Analyze Network Traffic Using Wireshark"**. It explains key networking concepts in a simple way, helping learners and enthusiasts understand how to interpret network data.

## 🔍 What's Inside

- ✅ **Wireshark Basics** – Understand what Wireshark is and how it's used.
- ✅ **What Are Packets?** – Learn how data travels across networks.
- ✅ **Filtering Traffic** – Apply filters to isolate useful information.
- ✅ **TCP vs UDP** – Compare two core transport protocols.
- ✅ **DNS Queries** – See how domain names get translated to IPs.
- ✅ **Troubleshooting with Packets** – Use captures to detect issues.
- ✅ **Understanding Protocols** – Get familiar with common network protocols.
- ✅ **Encrypted Traffic Limits** – Learn what Wireshark can and can’t see.

## 🧰 Tools Used

- **Wireshark** (Latest Version)
- **Windows 11 / Linux OS**

## 🛠 Example Filters (Wireshark)

```wireshark
ip.addr == 192.168.1.1        # Traffic from or to a specific IP
http                          # Filter HTTP traffic only
tcp.port == 80                # Show packets using TCP port 80
```

## 📎 Key Takeaway

> While most of the traffic observed was clean and expected (like Google or McAfee connections), Wireshark still empowers us to spot suspicious behavior if needed — especially unusual ports or repeated unknown connections.

## 🔐 Can Wireshark Decrypt HTTPS?

Not by default. It can only decrypt encrypted traffic if you provide SSL/TLS keys or configure your system with proper debug logs.

## 📁 File Structure

```
Wireshark-Network-Traffic-Analysis/
├── README.md
├── Task5_Wireshark_Analysis.pdf
├── images/
├── filters/
│   └── common_filters.md
├── conclusions/
│   └── findings_summary.md
```

---

Stay curious and keep exploring networks safely! 🌐🧠
