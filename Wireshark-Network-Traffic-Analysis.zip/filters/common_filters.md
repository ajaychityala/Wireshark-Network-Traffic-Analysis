## Common Wireshark Filters

- ip.addr == 192.168.1.1
- http
- tcp.port == 80
